(function() {
	
var btnIn = document.querySelectorAll(".counter-action");
var tablo = document.querySelectorAll(".counter-input");

var form = document.querySelector(".response");
var conteiner = form.querySelector(".same-row");
var template = document.querySelector("#input-template").innerHTML;


for (var i = 0; i<btnIn.length; i++) {
	var btn = btnIn[i];

	btn.addEventListener("click", function(){

		var counterParent = this.parentNode;
		var input = counterParent.querySelector('.counter-input');

		var i = 11;
		
		var html = Mustache.render(template, {
			
			"label" : "text" + i
		});  
		



		if (this.dataset.action  == 'minus' ) {
			input.value++;

			conteiner.innerHTML = conteiner.innerHTML + html;
		 } 

		 else if (this.dataset.action  == 'plus' && input.value > 1) {
			input.value--;


		 } 

		 else return;

		// console.log(counterParent);

	});

}

// var form = document.querySelector(".response");
// var conteiner = form.querySelector(".same-row");
// var btnMinus = document.querySelectorAll(".counter-action");

// for (var i = 0; i<btnMinus.length; i++) {
// 	var btnMin = btnMinus[i];

// 	btnMin.addEventListener("click", function(){
// 		var counterParent = this.parentNode;
// 		var input = counterParent.querySelector('.counter-input');
// 		var div1 = document.createElement("div");
// 		div1.classList.add("row");
// 		var div2 = document.createElement("div");
// 		div2.classList.add("col");
// 		div2.classList.add("s-4");
// 		var label = document.createElement("label");
// 		var input = document.createElement("input");
// 		// input.type = "text";

// 		if (this.dataset.action  == 'plus' ) {
// 			div2.appendChild(label);
// 			div2.appendChild(input);
// 			div1.appendChild(div2);
			

// 			conteiner.appendChild(div1);


// 			console.log(counterParent);
// 		 } 

// 	});
// }






})();


// Фильтр числового поля 

// (function() {

// function filter_input(e,regexp)
// {
//   e=e || window.event;
//   var target=e.target || e.srcElement;
//   var isIE=document.all;

//   if (target.tagName.toUpperCase()=='INPUT')
//   {
//     var code=isIE ? e.keyCode : e.which;
//     if (code<32 || e.ctrlKey || e.altKey) return true;

//     var char=String.fromCharCode(code);
//     if (!regexp.test(char)) return false;
//   }
//   return true;
// }

// })();